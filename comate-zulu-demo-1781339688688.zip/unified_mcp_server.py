"""
统一MCP服务器 - 同时启动读入文档和修改文档的所有MCP服务

功能：
1. 第1步 - 文档读取：读取文档内容，输出JSON
2. 第6步 - 文档修订：根据检查建议修订文档

支持格式：Word文档(.docx)、WPS文档(.wps和.wpsx)
启动方式：stdio模式 或 SSE模式

使用方法:
    python unified_mcp_server.py [--transport stdio|sse] [--host 0.0.0.0] [--port 8000]

端点(SSE模式):
    GET /sse - SSE连接端点
    POST /messages - 发送消息
    GET /health - 健康检查
    GET /tools - 获取工具定义
"""

import json
import os
import re
import sys
import logging
import zipfile
import argparse
from pathlib import Path
from typing import Optional, List, Dict, Any
from dataclasses import dataclass, asdict
from datetime import datetime
from enum import Enum

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger('UnifiedMCPServer')

# FastMCP导入
try:
    from fastmcp import FastMCP
    FASTMCP_AVAILABLE = True
except ImportError:
    FASTMCP_AVAILABLE = False
    logger.warning("fastmcp未安装，请运行: pip install fastmcp")

# 文档处理库
try:
    from docx import Document as DocxDocument
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.shared import RGBColor, Pt
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    DOCX_AVAILABLE = True
except ImportError:
    DOCX_AVAILABLE = False
    logger.warning("python-docx未安装，请运行: pip install python-docx")


# ============================================================
# 数据模型
# ============================================================

@dataclass
class DocumentMetadata:
    """文档元数据模型"""
    title: str = ""
    author: str = ""
    created_date: str = ""
    modified_date: str = ""
    file_type: str = ""
    file_size: int = 0
    paragraph_count: int = 0
    table_count: int = 0
    page_count: Optional[int] = None
    company: Optional[str] = None


@dataclass
class CheckSuggestion:
    """检查建议数据模型"""
    id: str = ""
    rule_id: str = ""
    rule_name: str = ""
    type: str = ""
    severity: str = "Medium"
    section: str = ""
    original_text: str = ""
    suggestion: str = ""
    reason: str = ""

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'CheckSuggestion':
        """从字典创建CheckSuggestion"""
        return cls(
            id=data.get('id', ''),
            rule_id=data.get('rule_id', ''),
            rule_name=data.get('rule_name', ''),
            type=data.get('type', ''),
            severity=data.get('severity', 'Medium'),
            section=data.get('section', ''),
            original_text=data.get('original_text', ''),
            suggestion=data.get('suggestion', ''),
            reason=data.get('reason', '')
        )


class Severity(Enum):
    """建议严重程度"""
    CRITICAL = "Critical"
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"


# ============================================================
# 文档读取器
# ============================================================

class DocumentReader:
    """文档读取器 - 支持docx/wps/wpsx"""

    @staticmethod
    def read_document(file_path: str) -> Dict[str, Any]:
        """
        读取文档，返回文本内容和元数据
        
        Args:
            file_path: 文档路径
            
        Returns:
            Dict包含document_content和document_metadata
        """
        logger.info(f"开始读取文档: {file_path}")

        if not file_path or not file_path.strip():
            raise ValueError("文件路径不能为空")

        file_path = file_path.strip()

        if not os.path.exists(file_path):
            raise FileNotFoundError(f"文件不存在: {file_path}")

        ext = Path(file_path).suffix.lower()

        if ext == '.docx':
            return DocumentReader._read_docx(file_path)
        elif ext in ['.wps', '.wpsx']:
            return DocumentReader._read_wps(file_path)
        else:
            raise ValueError(f"不支持的文档格式: {ext}，仅支持 .docx, .wps, .wpsx")

    @staticmethod
    def _read_docx(file_path: str) -> Dict[str, Any]:
        """读取Word文档"""
        if not DOCX_AVAILABLE:
            raise ImportError("python-docx库未安装，请运行: pip install python-docx")

        logger.info("读取Word文档 (.docx)")

        doc = DocxDocument(file_path)
        
        # 提取段落文本
        paragraphs = []
        full_text_lines = []
        
        for i, para in enumerate(doc.paragraphs):
            text = para.text.strip()
            if text:
                paragraphs.append({
                    'index': i,
                    'text': text,
                    'style': para.style.name if para.style else 'Normal'
                })
                full_text_lines.append(text)

        # 提取表格内容
        tables = []
        for i, table in enumerate(doc.tables):
            table_data = []
            for row in table.rows:
                row_data = [cell.text for cell in row.cells]
                table_data.append(row_data)
            tables.append({
                'index': i,
                'rows': len(table.rows),
                'cols': len(table.rows[0].cells) if table.rows else 0,
                'data': table_data
            })

        # 提取元数据
        metadata = DocumentReader._extract_docx_metadata(doc, file_path)

        # 构建完整文本
        full_text = '\n'.join(full_text_lines)
        
        # 添加表格文本表示
        if tables:
            full_text += '\n\n【表格内容】\n'
            for table in tables:
                full_text += f'\n表{table["index"] + 1}:\n'
                for row_data in table['data']:
                    full_text += '| ' + ' | '.join(row_data) + ' |\n'

        logger.info(f"读取完成: {len(paragraphs)}个段落, {len(tables)}个表格")

        return {
            'success': True,
            'document_content': full_text,
            'document_metadata': {
                'title': metadata.title,
                'author': metadata.author,
                'created_date': metadata.created_date,
                'modified_date': metadata.modified_date,
                'file_type': metadata.file_type,
                'file_size': metadata.file_size,
                'paragraph_count': len(paragraphs),
                'table_count': len(tables),
                'page_count': metadata.page_count,
                'company': metadata.company
            },
            'structured_content': {
                'paragraphs': paragraphs,
                'tables': tables
            },
            'file_path': file_path
        }

    @staticmethod
    def _read_wps(file_path: str) -> Dict[str, Any]:
        """读取WPS文档（使用OOXML格式解析）"""
        logger.info("读取WPS文档 (.wps/.wpsx)")

        # WPS文档实际上是OOXML格式，可以像docx一样解析
        try:
            return DocumentReader._read_docx(file_path)
        except Exception as e:
            logger.warning(f"使用docx解析WPS失败，尝试使用zip解析: {e}")
            return DocumentReader._read_wps_via_zip(file_path)

    @staticmethod
    def _read_wps_via_zip(file_path: str) -> Dict[str, Any]:
        """通过ZIP方式读取WPS文档"""
        paragraphs = []
        tables = []
        
        try:
            with zipfile.ZipFile(file_path, 'r') as zf:
                # 读取document.xml
                if 'word/document.xml' in zf.namelist():
                    doc_xml = zf.read('word/document.xml').decode('utf-8')
                    # 简单提取文本（去除XML标签）
                    import re
                    text_content = re.sub(r'<[^>]+>', '', doc_xml)
                    paragraphs = [{'index': i, 'text': line.strip(), 'style': 'Normal'} 
                                  for i, line in enumerate(text_content.split('\n')) if line.strip()]
        except Exception as e:
            logger.error(f"读取WPS文档失败: {e}")
            raise

        full_text = '\n'.join([p['text'] for p in paragraphs])
        
        # 获取文件信息
        file_stat = os.stat(file_path)
        metadata = DocumentMetadata(
            title=Path(file_path).stem,
            author='',
            created_date=datetime.fromtimestamp(file_stat.st_ctime).isoformat(),
            modified_date=datetime.fromtimestamp(file_stat.st_mtime).isoformat(),
            file_type='wps',
            file_size=file_stat.st_size,
            paragraph_count=len(paragraphs),
            table_count=len(tables)
        )

        logger.info(f"WPS读取完成: {len(paragraphs)}个段落")

        return {
            'success': True,
            'document_content': full_text,
            'document_metadata': {
                'title': metadata.title,
                'author': metadata.author,
                'created_date': metadata.created_date,
                'modified_date': metadata.modified_date,
                'file_type': metadata.file_type,
                'file_size': metadata.file_size,
                'paragraph_count': len(paragraphs),
                'table_count': len(tables),
                'page_count': metadata.page_count,
                'company': metadata.company
            },
            'structured_content': {
                'paragraphs': paragraphs,
                'tables': tables
            },
            'file_path': file_path
        }

    @staticmethod
    def _extract_docx_metadata(doc, file_path: str) -> DocumentMetadata:
        """提取docx文档元数据"""
        file_stat = os.stat(file_path)
        
        # 从core_properties获取元数据
        try:
            core_props = doc.core_properties
            title = core_props.title or Path(file_path).stem
            author = core_props.author or ''
            created = core_props.created.isoformat() if core_props.created else ''
            modified = core_props.modified.isoformat() if core_props.modified else ''
        except Exception:
            title = Path(file_path).stem
            author = ''
            created = datetime.fromtimestamp(file_stat.st_ctime).isoformat()
            modified = datetime.fromtimestamp(file_stat.st_mtime).isoformat()

        return DocumentMetadata(
            title=title,
            author=author,
            created_date=created,
            modified_date=modified,
            file_type='docx',
            file_size=file_stat.st_size,
            paragraph_count=len(doc.paragraphs),
            table_count=len(doc.tables)
        )


# ============================================================
# 文档修订器
# ============================================================

class DocumentReviser:
    """文档修订器 - 支持修订模式"""

    @staticmethod
    def clean_json_string(json_str: str) -> str:
        """
        清理JSON字符串，去除Markdown代码块标记
        
        用于处理LLM输出的带Markdown标记的JSON字符串
        例如：```json\n{...}\n``` → {...}
        
        Args:
            json_str: 可能包含Markdown标记的JSON字符串
            
        Returns:
            纯净的JSON字符串
        """
        if not json_str:
            return json_str
        
        # 去除开头的Markdown标记
        json_str = re.sub(r'^\s*```json\s*', '', json_str.strip(), flags=re.IGNORECASE)
        json_str = re.sub(r'^\s*```\s*', '', json_str.strip())
        
        # 去除结尾的Markdown标记
        json_str = re.sub(r'\s*```\s*$', '', json_str)
        
        return json_str.strip()

    @staticmethod
    def revise_document(file_path: str, suggestions_json: str, output_path: str = "", use_track_changes: str = "comment") -> Dict[str, Any]:
        """
        根据检查建议修订文档
        
        Args:
            file_path: 原文档路径
            suggestions_json: 检查建议JSON字符串
            output_path: 输出路径（可选）
            use_track_changes: 是否使用修订模式
            
        Returns:
            修订结果字典
        """
        logger.info(f"开始修订文档: {file_path}")
        
        if not file_path or not suggestions_json:
            return {
                'success': False,
                'error': '缺少必需参数',
                'error_type': 'ValidationError'
            }
        
        if not os.path.exists(file_path):
            return {
                'success': False,
                'error': f'文件不存在: {file_path}',
                'error_type': 'FileNotFoundError'
            }
        
        # 解析建议JSON（自动清理Markdown标记）
        try:
            # 清理可能的Markdown代码块标记
            clean_json = DocumentReviser.clean_json_string(suggestions_json)
            suggestions_data = json.loads(clean_json)
            if isinstance(suggestions_data, dict):
                suggestions = suggestions_data.get('suggestions', [])
            elif isinstance(suggestions_data, list):
                suggestions = suggestions_data
            else:
                suggestions = []
        except json.JSONDecodeError as e:
            return {
                'success': False,
                'error': f'JSON解析错误: {str(e)}',
                'error_type': 'JSONParseError'
            }
        
        if not suggestions:
            return {
                'success': False,
                'error': '没有可应用的修订建议',
                'error_type': 'NoSuggestionsError'
            }
        
        # 确定输出路径
        if not output_path:
            file_name = Path(file_path).stem
            file_ext = Path(file_path).suffix
            output_path = f"{file_name}_revised{file_ext}"
        
        # 执行修订
        # 注意：use_track_changes 可以是 'true', 'comment', 'false' 三种字符串
        
        try:
            ext = Path(file_path).suffix.lower()
            if ext == '.docx':
                result = DocumentReviser._revise_docx(file_path, suggestions, output_path, use_track_changes)
            elif ext in ['.wps', '.wpsx']:
                result = DocumentReviser._revise_wps(file_path, suggestions, output_path, use_track_changes)
            else:
                return {
                    'success': False,
                    'error': f'不支持的文档格式: {ext}',
                    'error_type': 'UnsupportedFormatError'
                }
            
            # 生成修改记录明细文档
            if result.get('success') and result.get('applied_revisions', 0) > 0:
                log_path = DocumentReviser._write_revision_log(file_path, result.get('revisions_detail', []), suggestions)
                if log_path:
                    result['revision_log_path'] = log_path
                    logger.info(f"修改记录文档已生成: {log_path}")
            
            return result
            
        except Exception as e:
            logger.exception("修订文档失败")
            return {
                'success': False,
                'error': f'修订失败: {str(e)}',
                'error_type': type(e).__name__
            }

    @staticmethod
    def _create_track_changes_element(element_type: str, text: str, author: str = "DocumentReviser", date: str = None) -> OxmlElement:
        """
        创建Word修订模式的XML元素

        Args:
            element_type: 'del' 或 'ins'
            text: 文本内容
            author: 修订作者
            date: 修订日期（ISO格式）

        Returns:
            OxmlElement: 修订元素
        """
        if date is None:
            date = datetime.now().astimezone().strftime("%Y-%m-%dT%H:%M:%SZ")

        # 创建修订元素
        if element_type == 'del':
            element = OxmlElement('w:del')
            element.set(qn('w:id'), str(hash(text) % 1000000))
            element.set(qn('w:author'), author)
            element.set(qn('w:date'), date)
        else:  # ins
            element = OxmlElement('w:ins')
            element.set(qn('w:id'), str(hash(text) % 1000000 + 1))
            element.set(qn('w:author'), author)
            element.set(qn('w:date'), date)

        # 创建 run 元素包含文本
        run = OxmlElement('w:r')

        # 创建文本元素
        text_elem = OxmlElement('w:t')
        text_elem.text = text

        run.append(text_elem)
        element.append(run)

        return element

    @staticmethod
    def _apply_track_changes_to_paragraph(para, original: str, new_text: str, revision_id: int) -> bool:
        """
        在段落中应用真正的Word修订模式（使用w:del和w:ins元素）

        Args:
            para: 段落对象
            original: 原文本
            new_text: 新文本
            revision_id: 修订ID

        Returns:
            bool: 是否成功应用
        """
        from docx.oxml import OxmlElement
        from docx.oxml.ns import qn

        # 获取段落的XML元素
        p = para._p

        # 查找包含原文的run
        found = False
        date_str = datetime.now().astimezone().strftime("%Y-%m-%dT%H:%M:%SZ")

        # 遍历所有run
        for run in para.runs:
            if original in run.text:
                # 找到包含原文的run
                r = run._r

                # 创建删除元素 (w:del)
                del_elem = OxmlElement('w:del')
                del_elem.set(qn('w:id'), str(revision_id))
                del_elem.set(qn('w:author'), 'DocumentReviser')
                del_elem.set(qn('w:date'), date_str)

                # 在删除元素中创建run包含原文
                del_run = OxmlElement('w:r')
                del_text = OxmlElement('w:t')
                del_text.text = original
                del_run.append(del_text)
                del_elem.append(del_run)

                # 创建插入元素 (w:ins)
                ins_elem = OxmlElement('w:ins')
                ins_elem.set(qn('w:id'), str(revision_id + 1))
                ins_elem.set(qn('w:author'), 'DocumentReviser')
                ins_elem.set(qn('w:date'), date_str)

                # 在插入元素中创建run包含新文本
                ins_run = OxmlElement('w:r')
                ins_text = OxmlElement('w:t')
                ins_text.text = new_text
                ins_run.append(ins_text)
                ins_elem.append(ins_run)

                # 替换原文run
                # 先添加删除和插入元素到段落
                p.append(del_elem)
                p.append(ins_elem)

                # 删除原文run
                p.remove(r)

                found = True
                break

        return found

    @staticmethod
    def _revise_docx(file_path: str, suggestions: List[Dict], output_path: str, use_track_changes: str) -> Dict[str, Any]:
        """修订Word文档"""
        if not DOCX_AVAILABLE:
            raise ImportError("python-docx库未安装")

        doc = DocxDocument(file_path)

        applied_count = 0
        revisions_detail = []
        revision_id = 1000  # 起始修订ID

        # 按顺序应用建议
        for suggestion in suggestions:
            original = suggestion.get('original_text', '')
            new_text = suggestion.get('suggestion', '')

            if not original:
                continue

            # 在文档中查找并替换
            found = False
            for para in doc.paragraphs:
                if original in para.text:
                    if use_track_changes == 'true':
                        # 使用真正的Word修订模式
                        success = DocumentReviser._apply_track_changes_to_paragraph(
                            para, original, new_text, revision_id
                        )
                        if success:
                            found = True
                            applied_count += 1
                            revision_id += 2  # 每次修订使用两个ID（del和ins）
                    elif use_track_changes == 'comment':
                        # 在原文后插入红色括号说明（不修改原文）
                        success = DocumentReviser._add_red_comment_to_paragraph(
                            para, original, new_text, suggestion.get('reason', ''), 
                            suggestion.get('rule_id', ''), revision_id
                        )
                        if success:
                            found = True
                            applied_count += 1
                            revision_id += 1
                    else:
                        # 直接替换模式
                        para.text = para.text.replace(original, new_text)
                        found = True
                        applied_count += 1
                    break

            revisions_detail.append({
                'id': suggestion.get('id', ''),
                'rule_id': suggestion.get('rule_id', ''),
                'original': original,
                'new': new_text,
                'status': 'success' if found else 'not_found'
            })

        # 保存文档
        doc.save(output_path)

        return {
            'success': True,
            'output_path': output_path,
            'use_track_changes': use_track_changes,
            'total_suggestions': len(suggestions),
            'applied_revisions': applied_count,
            'revisions_detail': revisions_detail
        }

    @staticmethod
    def _add_red_comment_to_paragraph(para, original: str, new_text: str, reason: str, 
                                       rule_id: str, comment_id: int) -> bool:
        """
        在段落中原文后插入红色括号说明（不修改原文）
        
        格式：（【建议】xxx 【原因】xxx 【规则】xxx）
        样式：红色字体
        
        Args:
            para: 段落对象
            original: 原文（保留不修改）
            new_text: 修改建议
            reason: 修改原因
            rule_id: 规则ID
            comment_id: 批注ID（用于标识）
            
        Returns:
            bool: 是否成功添加
        """
        try:
            from docx.shared import RGBColor
            
            # 查找原文位置
            if original not in para.text:
                return False
            
            # 构建说明文本（不包含原文，原文保留，不包含规则ID）
            comment_text = f"（【建议】{new_text} 【原因】{reason}）"
            
            # 保存原始文本
            full_text = para.text
            
            # 在原文后插入说明（只替换第一次出现）
            # 找到原文结束的位置
            idx = full_text.find(original)
            if idx == -1:
                return False
            
            # 分割文本：原文前 + 原文 + 说明 + 原文后
            before_text = full_text[:idx + len(original)]
            after_text = full_text[idx + len(original):]
            
            # 清空段落并重新构建
            para.clear()
            
            # 添加原文前部分（如果有）
            if before_text:
                para.add_run(before_text)
            
            # 添加红色说明
            red_run = para.add_run(comment_text)
            red_run.font.color.rgb = RGBColor(255, 0, 0)  # 红色
            # 设置字体稍小
            red_run.font.size = None  # 使用默认大小
            
            # 添加原文后部分（如果有）
            if after_text:
                para.add_run(after_text)
            
            return True
            
        except Exception as e:
            logger.error(f"添加红色说明失败: {e}")
            import traceback
            traceback.print_exc()
            return False

    @staticmethod
    def _revise_wps(file_path: str, suggestions: List[Dict], output_path: str, use_track_changes: str) -> Dict[str, Any]:
        """修订WPS文档（复用docx逻辑）"""
        return DocumentReviser._revise_docx(file_path, suggestions, output_path, use_track_changes)

    @staticmethod
    def _get_revision_log_path(file_path: str) -> str:
        """
        获取修改记录文档路径
        与原文档同目录，文件名为：原文件名_revision_log.docx
        """
        file_dir = Path(file_path).parent
        file_stem = Path(file_path).stem
        return str(file_dir / f"{file_stem}_revision_log.docx")

    @staticmethod
    def _get_existing_revision_count(log_path: str) -> int:
        """
        读取已有修改记录文档，获取已存在的修改次数
        
        Args:
            log_path: 修改记录文档路径
            
        Returns:
            已有修改次数（行数）
        """
        if not os.path.exists(log_path):
            return 0
        
        try:
            doc = DocxDocument(log_path)
            count = 0
            for para in doc.paragraphs:
                text = para.text.strip()
                # 统计"第N次修改"的标题出现的次数
                if text.startswith("第") and "次修改" in text:
                    count += 1
            return count
        except Exception:
            return 0

    @staticmethod
    def _write_revision_log(revised_file_path: str, revisions_detail: List[Dict], 
                             suggestions: List[Dict]) -> str:
        """
        生成或追加修改记录明细文档
        
        创建一个本地DOCX文档记录对文件的修改明细，内容包括：
        - 第几次修改
        - 修改时间
        - 修改概述（修改了哪些内容类型、严重程度分布等）
        - 修改内容明细（每条修改的原文、修改后内容、原因）
        
        Args:
            revised_file_path: 修订后的文档路径
            revisions_detail: 修订详情列表（来自修订结果）
            suggestions: 原始建议列表
            
        Returns:
            修改记录文档路径
        """
        if not DOCX_AVAILABLE:
            logger.warning("python-docx未安装，无法生成修改记录文档")
            return ""
        
        now = datetime.now()
        log_path = DocumentReviser._get_revision_log_path(revised_file_path)
        
        # 检查是否已有修改记录文档，决定是创建还是追加
        existing_count = DocumentReviser._get_existing_revision_count(log_path)
        revision_number = existing_count + 1
        
        # 生成修改概述
        by_severity = {}
        by_type = {}
        for sug in suggestions:
            sev = sug.get('severity', 'Unknown')
            by_severity[sev] = by_severity.get(sev, 0) + 1
            tp = sug.get('type', 'Unknown')
            by_type[tp] = by_type.get(tp, 0) + 1
        
        severity_summary = "、".join([f"{k}: {v}条" for k, v in sorted(by_severity.items())])
        type_summary = "、".join([f"{k}: {v}条" for k, v in sorted(by_type.items())])
        total = len(revisions_detail)
        success_count = sum(1 for r in revisions_detail if r.get('status') == 'success')
        
        summary_text = f"共修订{total}条内容，成功应用{success_count}条；严重程度分布：{severity_summary}；类型分布：{type_summary}"
        
        # 打开或创建文档
        if os.path.exists(log_path):
            doc = DocxDocument(log_path)
        else:
            doc = DocxDocument()
            # 添加文档标题
            para = doc.add_paragraph()
            run = para.add_run(f"文件修改记录明细")
            run.bold = True
            run.font.size = Pt(16)
            para.alignment = WD_ALIGN_PARAGRAPH.CENTER
            
            # 添加被修改文件信息
            doc.add_paragraph(f"被修改文件：{Path(revised_file_path).name}")
            doc.add_paragraph("")
        
        # 分隔线（追加时区分新旧记录）
        if existing_count > 0:
            p = doc.add_paragraph()
            run = p.add_run("─" * 50)
            run.font.color.rgb = RGBColor(128, 128, 128)
        
        # 第几次修改标题
        p = doc.add_paragraph()
        run = p.add_run(f"第{revision_number}次修改")
        run.bold = True
        run.font.size = Pt(14)
        
        # 修改时间
        doc.add_paragraph(f"修改时间：{now.strftime('%Y-%m-%d %H:%M:%S')}")
        
        # 修改概述
        p = doc.add_paragraph()
        run = p.add_run("修改概述：")
        run.bold = True
        doc.add_paragraph(summary_text)
        doc.add_paragraph("")
        
        # 修改内容明细
        p = doc.add_paragraph()
        run = p.add_run("修改内容明细：")
        run.bold = True
        doc.add_paragraph("")
        
        for i, (rev, sug) in enumerate(zip(revisions_detail, suggestions)):
            seq = i + 1
            status_icon = "✅" if rev.get('status') == 'success' else "❌"
            
            # 序号和状态
            p = doc.add_paragraph()
            run = p.add_run(f"{seq}. [{status_icon}] {rev.get('id', '')}")
            run.bold = True
            
            # 规则信息
            rule_name = sug.get('rule_name', '')
            if rule_name:
                doc.add_paragraph(f"   规则：{rule_name}（{sug.get('rule_id', '')}）")
            
            doc.add_paragraph(f"   类型：{sug.get('type', '')}　严重程度：{sug.get('severity', '')}")
            doc.add_paragraph(f"   状态：{'已应用' if rev.get('status') == 'success' else '未找到原文'}")
            doc.add_paragraph(f"   原文：{rev.get('original', '')}")
            
            # 修改后内容
            p = doc.add_paragraph()
            run = p.add_run(f"   修改后：{rev.get('new', '')}")
            run.font.color.rgb = RGBColor(0, 100, 0)  # 深绿色
            
            # 修改原因
            reason = sug.get('reason', '')
            if reason:
                p = doc.add_paragraph()
                run = p.add_run(f"   原因：{reason}")
                run.font.color.rgb = RGBColor(128, 128, 128)  # 灰色
            
            doc.add_paragraph("")  # 空行分隔
        
        # 保存
        doc.save(log_path)
        logger.info(f"修改记录文档已保存: {log_path}, 第{revision_number}次修改, 共{total}条")
        
        return log_path


# ============================================================
# MCP服务器初始化
# ============================================================

if FASTMCP_AVAILABLE:
    mcp = FastMCP("UnifiedDocumentServer")

    # ============================================================
    # 第1步 - 文档读取工具
    # ============================================================

    @mcp.tool()
    def read_document(file_path: str) -> str:
        """
        读取文档内容，返回文档文本和元数据（第1步）
        
        Args:
            file_path: 文档路径，支持 .docx、.wps、.wpsx 格式
            
        Returns:
            JSON字符串，包含document_content和document_metadata
        """
        start_time = datetime.now()
        call_id = f"read_{start_time.strftime('%Y%m%d_%H%M%S')}"

        logger.info(f"[{call_id}] 开始读取文档: {file_path}")

        try:
            if not file_path or not file_path.strip():
                return json.dumps({
                    "success": False,
                    "error": "file_path不能为空",
                    "error_type": "ValidationError",
                    "call_id": call_id
                }, ensure_ascii=False)

            reader = DocumentReader()
            result = reader.read_document(file_path)
            result['call_id'] = call_id
            result['timestamp'] = datetime.now().isoformat()

            logger.info(f"[{call_id}] 读取完成: {result['document_metadata']['paragraph_count']}个段落")
            return json.dumps(result, ensure_ascii=False, indent=2)

        except Exception as e:
            logger.exception(f"[{call_id}] 读取异常")
            return json.dumps({
                "success": False,
                "error": f"读取失败: {str(e)}",
                "error_type": type(e).__name__,
                "call_id": call_id,
                "timestamp": datetime.now().isoformat()
            }, ensure_ascii=False)

    @mcp.tool()
    def get_document_info(file_path: str) -> str:
        """
        获取文档基本信息（第1步辅助工具）
        
        Args:
            file_path: 文档路径
            
        Returns:
            JSON字符串，包含文档基本信息
        """
        start_time = datetime.now()
        call_id = f"info_{start_time.strftime('%Y%m%d_%H%M%S')}"

        logger.info(f"[{call_id}] 获取文档信息: {file_path}")

        try:
            if not file_path or not file_path.strip():
                return json.dumps({
                    "success": False,
                    "error": "file_path不能为空",
                    "call_id": call_id
                }, ensure_ascii=False)

            file_path = file_path.strip()

            if not os.path.exists(file_path):
                return json.dumps({
                    "success": False,
                    "error": f"文件不存在: {file_path}",
                    "call_id": call_id
                }, ensure_ascii=False)

            file_stat = os.stat(file_path)
            file_type = Path(file_path).suffix.lower()

            result = {
                "success": True,
                "file_path": file_path,
                "file_name": Path(file_path).name,
                "file_type": file_type,
                "file_size": file_stat.st_size,
                "file_size_readable": f"{file_stat.st_size / 1024:.2f} KB",
                "created_time": datetime.fromtimestamp(file_stat.st_ctime).isoformat(),
                "modified_time": datetime.fromtimestamp(file_stat.st_mtime).isoformat(),
                "call_id": call_id,
                "timestamp": datetime.now().isoformat()
            }

            return json.dumps(result, ensure_ascii=False, indent=2)

        except Exception as e:
            logger.exception(f"[{call_id}] 获取信息异常")
            return json.dumps({
                "success": False,
                "error": f"获取信息失败: {str(e)}",
                "error_type": type(e).__name__,
                "call_id": call_id
            }, ensure_ascii=False)

    # ============================================================
    # 第6步 - 文档修订工具
    # ============================================================

    @mcp.tool()
    def revise_document(file_path: str, suggestions_json: str, output_path: str = "", use_track_changes: str = "comment") -> str:
        """
        根据检查建议修订文档（第6步）

        支持三种修订模式：
        1. Word原生修订模式（Track Changes）：使用w:del和w:ins元素标记修改
        2. 红色括号说明模式：在原文后插入红色括号说明，不修改原文
        3. 直接替换模式：直接替换原文

        Args:
            file_path: 原文档路径
            suggestions_json: 检查建议JSON字符串
            output_path: 输出路径（可选）
            use_track_changes: 修订模式
                - 'true'（默认）：启用Word修订追踪（Track Changes）
                - 'comment'：在原文后插入红色括号说明
                - 'false'：直接替换原文

        Returns:
            JSON字符串，包含修订结果
        """
        start_time = datetime.now()
        call_id = f"revise_{start_time.strftime('%Y%m%d_%H%M%S')}"

        logger.info(f"[{call_id}] 开始修订文档")
        logger.info(f"[{call_id}] file_path: {file_path}")
        logger.info(f"[{call_id}] use_track_changes: {use_track_changes}")

        try:
            reviser = DocumentReviser()
            result = reviser.revise_document(file_path, suggestions_json, output_path, use_track_changes)
            result['call_id'] = call_id
            result['timestamp'] = datetime.now().isoformat()

            logger.info(f"[{call_id}] 修订完成: {result.get('applied_revisions', 0)}条修订应用")
            return json.dumps(result, ensure_ascii=False, indent=2)

        except Exception as e:
            logger.exception(f"[{call_id}] 修订异常")
            return json.dumps({
                "success": False,
                "error": f"修订失败: {str(e)}",
                "error_type": type(e).__name__,
                "call_id": call_id,
                "timestamp": datetime.now().isoformat()
            }, ensure_ascii=False)

    @mcp.tool()
    def validate_suggestions(suggestions_json: str) -> str:
        """
        验证检查建议JSON格式
        
        Args:
            suggestions_json: 检查建议JSON字符串
            
        Returns:
            JSON字符串，包含验证结果
        """
        start_time = datetime.now()
        call_id = f"validate_{start_time.strftime('%Y%m%d_%H%M%S')}"

        logger.info(f"[{call_id}] 验证建议JSON")

        try:
            data = json.loads(suggestions_json)
            
            if isinstance(data, dict):
                suggestions = data.get("suggestions", [])
            elif isinstance(data, list):
                suggestions = data
            else:
                return json.dumps({
                    "success": False,
                    "valid": False,
                    "error": "输入必须是JSON数组或包含suggestions的对象",
                    "call_id": call_id
                }, ensure_ascii=False)

            return json.dumps({
                "success": True,
                "valid": True,
                "count": len(suggestions),
                "message": f"验证通过，共{len(suggestions)}条建议",
                "call_id": call_id,
                "timestamp": datetime.now().isoformat()
            }, ensure_ascii=False)

        except json.JSONDecodeError as e:
            return json.dumps({
                "success": False,
                "valid": False,
                "error": f"JSON解析错误: {str(e)}",
                "call_id": call_id
            }, ensure_ascii=False)

    @mcp.tool()
    def get_tools_info() -> str:
        """获取所有工具信息"""
        tools_info = {
            "name": "UnifiedDocumentServer",
            "version": "1.1.0",
            "description": "统一文档MCP服务器，支持文档读取和修订（含Word原生修订模式Track Changes）",
            "tools": [
                {
                    "name": "read_document",
                    "description": "读取文档内容（第1步）",
                    "category": "文档读取"
                },
                {
                    "name": "get_document_info",
                    "description": "获取文档基本信息（第1步辅助）",
                    "category": "文档读取"
                },
                {
                    "name": "revise_document",
                    "description": "根据建议修订文档（第6步）",
                    "category": "文档修订"
                },
                {
                    "name": "validate_suggestions",
                    "description": "验证建议JSON格式（第6步辅助）",
                    "category": "文档修订"
                }
            ]
        }
        return json.dumps(tools_info, ensure_ascii=False, indent=2)


# ============================================================
# 主入口
# ============================================================

def main():
    """主入口函数"""
    parser = argparse.ArgumentParser(description='统一文档MCP服务器')
    parser.add_argument(
        '--transport',
        choices=['stdio', 'sse'],
        default='stdio',
        help='传输方式: stdio (默认) 或 sse'
    )
    parser.add_argument(
        '--host',
        default='0.0.0.0',
        help='SSE模式下的主机地址 (默认: 0.0.0.0)'
    )
    parser.add_argument(
        '--port',
        type=int,
        default=8000,
        help='SSE模式下的端口号 (默认: 8000)'
    )

    args = parser.parse_args()

    print("=" * 70)
    print("统一文档MCP服务器（第1步 + 第6步）v1.1.0")
    print("新增功能：支持Word原生修订模式（Track Changes）")
    print("=" * 70)

    if not FASTMCP_AVAILABLE:
        print("\n错误: fastmcp未安装")
        print("请运行: pip install fastmcp")
        sys.exit(1)

    if not DOCX_AVAILABLE:
        print("\n错误: python-docx未安装")
        print("请运行: pip install python-docx")
        sys.exit(1)

    print(f"\n传输方式: {args.transport.upper()}")

    if args.transport == 'sse':
        print(f"服务地址: http://{args.host}:{args.port}")
        print(f"SSE端点: http://{args.host}:{args.port}/sse")
        print(f"消息端点: http://{args.host}:{args.port}/messages")

    print("\n可用工具:")
    print("  【第1步 - 文档读取】")
    print("    1. read_document      - 读取文档内容")
    print("    2. get_document_info  - 获取文档基本信息")
    print("  【第6步 - 文档修订】")
    print("    3. revise_document    - 根据建议修订文档")
    print("    4. validate_suggestions - 验证建议JSON")
    print("    5. get_tools_info     - 工具信息")
    print("\n启动服务...")
    print("-" * 70)

    # 启动FastMCP服务
    if args.transport == 'sse':
        mcp.run(transport='sse', host=args.host, port=args.port)
    else:
        mcp.run()


if __name__ == "__main__":
    main()
